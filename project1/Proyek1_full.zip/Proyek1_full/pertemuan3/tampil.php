<?php
include_once 'atas.php';
?>
<h1>Haii welcome to my website!!!</h1>
<?php
require_once 'bawah.php';
?>