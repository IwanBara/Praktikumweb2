<?php
include_once 'tes.php';
?>
<?php
echo "<br/>Hari ini Belajar fungsi include dan require";
?>