<footer>
        <p>Created By Mahasiswa <a href="https://elena.nurulfikri.ac.id/" target="_blank" > STT-NF</a> 21 & copyright 2022</p>
    </footer>
</body>
</html>