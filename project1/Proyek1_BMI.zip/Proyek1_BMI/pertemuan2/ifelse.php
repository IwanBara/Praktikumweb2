<?php
$teman = "aziza";

if($teman == "ucup"){
    echo "Aziza adalah teman saya";
}else{
    echo "Aziza bukan teman saya";
}
?>